import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Mail, Github, Linkedin } from "lucide-react";
import { motion } from "framer-motion";

export default function PortfolioSite() {
  const data = {
    name: "Shane Hussein",
    title: "General Manager – Commercial | Fijian Drua",
    tagline: "Marketing Leader | Brand Strategist | Creative Activator",
    about: `Shane Hussein is the General Manager of Commercial for the Fijian Drua, Fiji’s professional rugby franchise competing in Super Rugby Pacific. With over 20 years of experience in media, communications, and marketing, Shane is a brand building specialist who has played a key role in shaping two of Fiji’s most iconic brands: Fiji Airways and the Fijian Drua—both now synonymous with national pride and progress.

At the Drua, Shane leads all commercial and revenue-generating operations for the club, including sponsorship, ticketing, licensing, broadcasting, marketing, advertising, and digital engagement. His work supports the sustainability of a fully professional sports organisation, which includes men’s and women’s teams, a development squad, and an academy.

Prior to joining the Drua in 2022, Shane spent ten years with Fiji Airways, where he led functions such as Corporate Communications, Customer Loyalty, Events, and Social Media. One of his most notable marketing achievements came in 2013 during the rebrand of Fiji Airways, when he orchestrated a bold brand activation that earned a Guinness World Record for the world’s highest altitude wedding on an aircraft—five couples were married at 41,000 feet on a Fiji Airways flight, creating global media coverage and renewed consumer engagement.

He also served as Media Advisor to the U.S. Embassy in Suva, overseeing media strategy and public diplomacy across 11 Pacific Island nations.

Shane began his career in journalism as a news presenter, producer, and award-winning reporter with Fiji TV and Fiji One News. This early foundation in storytelling continues to influence his strategic approach to marketing and brand positioning.

Beyond his corporate role, Shane is a public member of the Fiji Media Council and serves as Chairman of the Fiji Awards for Media Excellence (FAME Awards).`,
    expertise: [
      "Brand Strategy",
      "Creative Campaigns",
      "Media & Communications",
      "Sports Marketing",
      "Public Diplomacy",
      "Stakeholder Engagement"
    ],
    accomplishments: [
      "Guinness World Record – Highest altitude wedding activation for Fiji Airways (2013)",
      "10 years leading key marketing and loyalty functions at Fiji Airways",
      "Oversees all commercial operations at Fijian Drua (Super Rugby Pacific)",
      "Former Media Advisor to the U.S. Embassy across 11 Pacific nations",
      "Chairman, Fiji Awards for Media Excellence",
      "Member, Fiji Media Council"
    ],
    contact: {
      email: "shanehussein@gmail.com",
      linkedin: "https://linkedin.com/in/shanehussein",
      github: ""
    }
  };

  return (
    <main className="p-6 max-w-5xl mx-auto space-y-6">
      <section className="text-center">
        <h1 className="text-4xl font-bold">{data.name}</h1>
        <p className="text-xl text-gray-600">{data.title}</p>
        <p className="mt-2 text-lg">{data.tagline}</p>
      </section>

      <section>
        <Card>
          <CardHeader>
            <CardTitle>About Me</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="whitespace-pre-line">{data.about}</p>
          </CardContent>
        </Card>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Expertise</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside">
              {data.expertise.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Accomplishments</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="list-disc list-inside">
              {data.accomplishments.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </section>

      <section>
        <Card>
          <CardHeader>
            <CardTitle>Contact</CardTitle>
          </CardHeader>
          <CardContent className="flex space-x-4">
            <a href={`mailto:${data.contact.email}`}><Mail /></a>
            <a href={data.contact.linkedin} target="_blank" rel="noopener noreferrer"><Linkedin /></a>
            {data.contact.github && <a href={data.contact.github}><Github /></a>}
          </CardContent>
        </Card>
      </section>
    </main>
  );
}